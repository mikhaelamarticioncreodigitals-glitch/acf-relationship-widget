<?php
namespace ACFRelWidget;

defined( 'ABSPATH' ) || exit;

/**
 * Elementor Widget: ACF Relationship Dynamic Widget
 *
 * Note: No `use` imports — we reference Elementor classes by fully-qualified
 * name so this file is safe to load before Elementor's own autoloader runs.
 */
class Elementor_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'acf_relationship_widget';
    }

    public function get_title() {
        return esc_html__( 'ACF Relationship', 'acf-rel-widget' );
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    public function get_keywords() {
        return [ 'acf', 'relationship', 'posts', 'dynamic', 'related' ];
    }

    public function get_script_depends() {
        return [ 'acf-rel-widget' ];
    }

    public function get_style_depends() {
        return [ 'acf-rel-widget' ];
    }

    // -------------------------------------------------------------------------
    // Controls
    // -------------------------------------------------------------------------

    protected function register_controls() {
        $this->section_source();
        $this->section_layout();
        $this->section_query();
        $this->section_card();
        $this->section_advanced_features();
        $this->section_style_card();
        $this->section_style_typography();
    }

    private function get_acf_relationship_fields() {
        $options = array( '' => '— ' . __( 'Select a field', 'acf-rel-widget' ) . ' —' );

        if ( ! function_exists( 'acf_get_field_groups' ) ) {
            return $options;
        }

        $groups = acf_get_field_groups();

        if ( empty( $groups ) ) {
            return $options;
        }

        foreach ( $groups as $group ) {
            $fields = acf_get_fields( $group['key'] );

            if ( empty( $fields ) ) {
                continue;
            }

            foreach ( $fields as $field ) {
                if ( $field['type'] === 'relationship' || $field['type'] === 'post_object' ) {
                    $label = $group['title'] . ' → ' . $field['label'] . ' (' . $field['name'] . ')';
                    $options[ $field['name'] ] = $label;
                }
            }
        }

        return $options;
    }

    private function section_source() {
        $this->start_controls_section( 'section_source', [
            'label' => esc_html__( 'Data Source', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $acf_fields = $this->get_acf_relationship_fields();

        // If ACF fields were found, show a dropdown; otherwise fall back to text input.
        if ( count( $acf_fields ) > 1 ) {
            $this->add_control( 'field_name', [
                'label'       => esc_html__( 'ACF Relationship Field', 'acf-rel-widget' ),
                'type'        => \Elementor\Controls_Manager::SELECT,
                'default'     => '',
                'options'     => $acf_fields,
                'description' => esc_html__( 'Select the ACF Relationship or Post Object field attached to the current post.', 'acf-rel-widget' ),
            ] );
        } else {
            $this->add_control( 'field_name', [
                'label'       => esc_html__( 'ACF Field Name', 'acf-rel-widget' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'placeholder' => 'team_members',
                'description' => esc_html__( 'No ACF Relationship fields found. Enter the field name manually.', 'acf-rel-widget' ),
            ] );
        }

        $this->add_control( 'empty_state', [
            'label'   => esc_html__( 'Empty State', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'hide',
            'options' => [
                'hide'    => esc_html__( 'Hide widget', 'acf-rel-widget' ),
                'message' => esc_html__( 'Show fallback message', 'acf-rel-widget' ),
            ],
        ] );

        $this->add_control( 'empty_message', [
            'label'     => esc_html__( 'Fallback Message', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'default'   => esc_html__( 'No related items found.', 'acf-rel-widget' ),
            'condition' => [ 'empty_state' => 'message' ],
        ] );

        $this->end_controls_section();
    }

    private function section_layout() {
        $this->start_controls_section( 'section_layout', [
            'label' => esc_html__( 'Layout', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'layout', [
            'label'   => esc_html__( 'Layout', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'grid',
            'options' => [
                'grid'     => esc_html__( 'Grid', 'acf-rel-widget' ),
                'carousel' => esc_html__( 'Carousel / Slider', 'acf-rel-widget' ),
                'list'     => esc_html__( 'List', 'acf-rel-widget' ),
                'table'    => esc_html__( 'Table', 'acf-rel-widget' ),
            ],
        ] );

        $this->add_responsive_control( 'columns', [
            'label'          => esc_html__( 'Columns', 'acf-rel-widget' ),
            'type'           => \Elementor\Controls_Manager::NUMBER,
            'default'        => 3,
            'tablet_default' => 2,
            'mobile_default' => 1,
            'min'            => 1,
            'max'            => 6,
            'condition'      => [ 'layout' => [ 'grid', 'carousel' ] ],
        ] );

        $this->add_responsive_control( 'gap', [
            'label'          => esc_html__( 'Item Gap', 'acf-rel-widget' ),
            'type'           => \Elementor\Controls_Manager::SLIDER,
            'size_units'     => [ 'px' ],
            'range'          => [ 'px' => [ 'min' => 0, 'max' => 80 ] ],
            'default'        => [ 'size' => 20, 'unit' => 'px' ],
            'tablet_default' => [ 'size' => 16, 'unit' => 'px' ],
            'mobile_default' => [ 'size' => 12, 'unit' => 'px' ],
            'selectors'      => [
                '{{WRAPPER}} .acf-rel-widget__items' => 'gap: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .swiper-wrapper'         => 'gap: 0;',
            ],
        ] );

        // Masonry / Equal Height toggle (grid only).
        $this->add_control( 'masonry', [
            'label'       => esc_html__( 'Masonry Layout', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::SWITCHER,
            'label_on'    => esc_html__( 'On', 'acf-rel-widget' ),
            'label_off'   => esc_html__( 'Off', 'acf-rel-widget' ),
            'default'     => '',
            'description' => esc_html__( 'Cards flow to different heights. Turn off for equal-height rows.', 'acf-rel-widget' ),
            'condition'   => [ 'layout' => 'grid' ],
        ] );

        // Carousel-specific.
        $this->add_control( 'carousel_autoplay', [
            'label'     => esc_html__( 'Autoplay', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SWITCHER,
            'label_on'  => esc_html__( 'Yes', 'acf-rel-widget' ),
            'label_off' => esc_html__( 'No', 'acf-rel-widget' ),
            'default'   => '',
            'condition' => [ 'layout' => 'carousel' ],
        ] );

        $this->add_control( 'carousel_autoplay_delay', [
            'label'     => esc_html__( 'Autoplay Delay (ms)', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::NUMBER,
            'default'   => 3000,
            'condition' => [ 'layout' => 'carousel', 'carousel_autoplay' => 'yes' ],
        ] );

        $this->end_controls_section();
    }

    private function get_post_types_options() {
        $options = array( 'any' => esc_html__( 'All Post Types', 'acf-rel-widget' ) );
        $post_types = get_post_types( array( 'public' => true ), 'objects' );
        foreach ( $post_types as $pt ) {
            $options[ $pt->name ] = $pt->label;
        }
        return $options;
    }

    private function get_taxonomies_options() {
        $options = array( '' => esc_html__( '— None —', 'acf-rel-widget' ) );
        $taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
        foreach ( $taxonomies as $tax ) {
            $options[ $tax->name ] = $tax->label;
        }
        return $options;
    }

    private function section_query() {
        $this->start_controls_section( 'section_query', [
            'label' => esc_html__( 'Query', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        // --- Source / Filter ---
        $this->add_control( 'query_post_type', [
            'label'   => esc_html__( 'Source', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'any',
            'options' => $this->get_post_types_options(),
        ] );

        // --- Include / Exclude tabs ---
        $this->add_control( 'query_include_exclude', [
            'label'   => esc_html__( 'Include / Exclude', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'include' => [ 'title' => esc_html__( 'Include', 'acf-rel-widget' ), 'icon' => 'eicon-plus-circle' ],
                'exclude' => [ 'title' => esc_html__( 'Exclude', 'acf-rel-widget' ), 'icon' => 'eicon-minus-circle' ],
            ],
            'default'      => 'include',
            'toggle'       => false,
            'label_block'  => false,
        ] );

        $this->add_control( 'query_include_ids', [
            'label'       => esc_html__( 'Include Posts', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__( 'Search post title…', 'acf-rel-widget' ),
            'description' => esc_html__( 'Type post titles separated by comma, or enter IDs. Leave empty for all related posts.', 'acf-rel-widget' ),
            'condition'   => [ 'query_include_exclude' => 'include' ],
            'classes'     => 'acf-rel-post-search',
        ] );

        $this->add_control( 'query_include_resolved', [
            'label'     => esc_html__( 'Resolved Include IDs', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::HIDDEN,
            'default'   => '',
            'condition' => [ 'query_include_exclude' => 'include' ],
        ] );

        $this->add_control( 'query_exclude_ids', [
            'label'       => esc_html__( 'Exclude Posts', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__( 'Search post title…', 'acf-rel-widget' ),
            'description' => esc_html__( 'Type post titles separated by comma, or enter IDs.', 'acf-rel-widget' ),
            'condition'   => [ 'query_include_exclude' => 'exclude' ],
            'classes'     => 'acf-rel-post-search',
        ] );

        $this->add_control( 'query_exclude_resolved', [
            'label'     => esc_html__( 'Resolved Exclude IDs', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::HIDDEN,
            'default'   => '',
            'condition' => [ 'query_include_exclude' => 'exclude' ],
        ] );

        // --- Date ---
        $this->add_control( 'query_date', [
            'label'     => esc_html__( 'Date', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'all',
            'separator' => 'before',
            'options'   => [
                'all'    => esc_html__( 'All', 'acf-rel-widget' ),
                'today'  => esc_html__( 'Today', 'acf-rel-widget' ),
                'week'   => esc_html__( 'This Week', 'acf-rel-widget' ),
                'month'  => esc_html__( 'This Month', 'acf-rel-widget' ),
                'year'   => esc_html__( 'This Year', 'acf-rel-widget' ),
                'custom' => esc_html__( 'Custom Range', 'acf-rel-widget' ),
            ],
        ] );

        $this->add_control( 'query_date_after', [
            'label'       => esc_html__( 'After (YYYY-MM-DD)', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => '2024-01-01',
            'condition'   => [ 'query_date' => 'custom' ],
        ] );

        $this->add_control( 'query_date_before', [
            'label'       => esc_html__( 'Before (YYYY-MM-DD)', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => '2024-12-31',
            'condition'   => [ 'query_date' => 'custom' ],
        ] );

        // --- Order By ---
        $this->add_control( 'orderby', [
            'label'     => esc_html__( 'Order By', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'post__in',
            'separator' => 'before',
            'options'   => [
                'post__in' => esc_html__( 'ACF Selection Order', 'acf-rel-widget' ),
                'date'     => esc_html__( 'Date', 'acf-rel-widget' ),
                'title'    => esc_html__( 'Title', 'acf-rel-widget' ),
                'rand'     => esc_html__( 'Random', 'acf-rel-widget' ),
                'modified' => esc_html__( 'Last Modified', 'acf-rel-widget' ),
            ],
        ] );

        $this->add_control( 'order', [
            'label'   => esc_html__( 'Order', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => 'DESC',
            'options' => [
                'ASC'  => esc_html__( 'ASC', 'acf-rel-widget' ),
                'DESC' => esc_html__( 'DESC', 'acf-rel-widget' ),
            ],
            'condition' => [ 'orderby!' => 'post__in' ],
        ] );

        // --- Ignore Sticky Posts ---
        $this->add_control( 'ignore_sticky', [
            'label'     => esc_html__( 'Ignore Sticky Posts', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SWITCHER,
            'default'   => 'yes',
            'separator' => 'before',
        ] );

        // --- Max Items (responsive) ---
        $this->add_responsive_control( 'limit', [
            'label'          => esc_html__( 'Max Items', 'acf-rel-widget' ),
            'type'           => \Elementor\Controls_Manager::NUMBER,
            'default'        => 6,
            'tablet_default' => 4,
            'mobile_default' => 2,
            'min'            => 1,
            'max'            => 100,
            'separator'      => 'before',
        ] );

        // --- Query ID ---
        $this->add_control( 'query_id', [
            'label'       => esc_html__( 'Query ID', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => 'my_custom_query',
            'description' => esc_html__( 'Give your query a custom unique ID for server-side filtering via the elementor/query/{ID} hook.', 'acf-rel-widget' ),
            'separator'   => 'before',
        ] );

        // --- Taxonomy Filter ---
        $this->add_control( 'tax_filter_heading', [
            'label'     => esc_html__( 'Taxonomy Filter', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'tax_filter_taxonomy', [
            'label'   => esc_html__( 'Taxonomy', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'default' => '',
            'options' => $this->get_taxonomies_options(),
        ] );

        $this->add_control( 'tax_filter_terms', [
            'label'       => esc_html__( 'Term Slugs (comma separated)', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'placeholder' => 'design, development',
            'condition'   => [ 'tax_filter_taxonomy!' => '' ],
        ] );

        $this->add_control( 'tax_filter_operator', [
            'label'     => esc_html__( 'Operator', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'IN',
            'options'   => [
                'IN'     => 'IN',
                'NOT IN' => 'NOT IN',
                'AND'    => 'AND',
            ],
            'condition' => [ 'tax_filter_taxonomy!' => '' ],
        ] );

        $this->end_controls_section();
    }

    private function section_card() {
        $this->start_controls_section( 'section_card', [
            'label' => esc_html__( 'Card / Template', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        // --- Featured Image ---
        $this->add_control( 'show_image', [
            'label'   => esc_html__( 'Show Featured Image', 'acf-rel-widget' ),
            'type'    => \Elementor\Controls_Manager::SWITCHER,
            'default' => 'yes',
        ] );

        $this->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), [
            'name'      => 'thumbnail',
            'default'   => 'medium',
            'condition' => [ 'show_image' => 'yes' ],
        ] );

        $this->add_control( 'image_position', [
            'label'     => esc_html__( 'Image Position', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'center center',
            'options'   => [
                'center center' => esc_html__( 'Center Center', 'acf-rel-widget' ),
                'center top'    => esc_html__( 'Center Top', 'acf-rel-widget' ),
                'center bottom' => esc_html__( 'Center Bottom', 'acf-rel-widget' ),
                'left top'      => esc_html__( 'Left Top', 'acf-rel-widget' ),
                'left center'   => esc_html__( 'Left Center', 'acf-rel-widget' ),
                'left bottom'   => esc_html__( 'Left Bottom', 'acf-rel-widget' ),
                'right top'     => esc_html__( 'Right Top', 'acf-rel-widget' ),
                'right center'  => esc_html__( 'Right Center', 'acf-rel-widget' ),
                'right bottom'  => esc_html__( 'Right Bottom', 'acf-rel-widget' ),
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-image' => 'object-position: {{VALUE}};' ],
            'condition' => [ 'show_image' => 'yes' ],
        ] );

        $this->add_control( 'image_attachment', [
            'label'     => esc_html__( 'Image Attachment', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'scroll',
            'options'   => [
                'scroll' => esc_html__( 'Scroll', 'acf-rel-widget' ),
                'fixed'  => esc_html__( 'Fixed', 'acf-rel-widget' ),
                'local'  => esc_html__( 'Local', 'acf-rel-widget' ),
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-image-wrap' => 'background-attachment: {{VALUE}};' ],
            'condition' => [ 'show_image' => 'yes' ],
        ] );

        $this->add_control( 'image_repeat', [
            'label'     => esc_html__( 'Image Repeat', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'no-repeat',
            'options'   => [
                'no-repeat' => esc_html__( 'No Repeat', 'acf-rel-widget' ),
                'repeat'    => esc_html__( 'Repeat', 'acf-rel-widget' ),
                'repeat-x'  => esc_html__( 'Repeat X', 'acf-rel-widget' ),
                'repeat-y'  => esc_html__( 'Repeat Y', 'acf-rel-widget' ),
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-image-wrap' => 'background-repeat: {{VALUE}};' ],
            'condition' => [ 'show_image' => 'yes' ],
        ] );

        $this->add_control( 'image_size_display', [
            'label'     => esc_html__( 'Image Display Size', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'cover',
            'options'   => [
                'cover'   => esc_html__( 'Cover', 'acf-rel-widget' ),
                'contain' => esc_html__( 'Contain', 'acf-rel-widget' ),
                'auto'    => esc_html__( 'Auto', 'acf-rel-widget' ),
                '100%'    => esc_html__( '100% Width', 'acf-rel-widget' ),
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-image' => 'object-fit: {{VALUE}};' ],
            'condition' => [ 'show_image' => 'yes' ],
        ] );

        $this->add_responsive_control( 'image_height', [
            'label'      => esc_html__( 'Image Height', 'acf-rel-widget' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'vh', '%' ],
            'range'      => [ 'px' => [ 'min' => 50, 'max' => 600 ] ],
            'default'    => [ 'size' => 200, 'unit' => 'px' ],
            'selectors'  => [ '{{WRAPPER}} .acf-rel-widget__card-image-wrap' => 'padding-top: 0; height: {{SIZE}}{{UNIT}};' ],
            'condition'  => [ 'show_image' => 'yes' ],
        ] );

        // --- Title ---
        $this->add_control( 'show_title', [
            'label'     => esc_html__( 'Show Title', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SWITCHER,
            'default'   => 'yes',
            'separator' => 'before',
        ] );

        $this->add_control( 'title_tag', [
            'label'     => esc_html__( 'Title HTML Tag', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => 'h3',
            'options'   => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'p' => 'P' ],
            'condition' => [ 'show_title' => 'yes' ],
        ] );

        // --- Link ---
        $this->add_control( 'link_target', [
            'label'     => esc_html__( 'Link Target', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'default'   => '_self',
            'separator' => 'before',
            'options'   => [
                '_self'  => esc_html__( 'Same Tab', 'acf-rel-widget' ),
                '_blank' => esc_html__( 'New Tab', 'acf-rel-widget' ),
            ],
        ] );

        // --- Elementor Loop Template (Pro) ---
        $this->add_control( 'elementor_loop_template', [
            'label'       => esc_html__( 'Elementor Loop Template ID (Pro)', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::NUMBER,
            'separator'   => 'before',
            'description' => esc_html__( 'Enter the ID of an Elementor Loop template. Overrides PHP card template.', 'acf-rel-widget' ),
        ] );

        $this->end_controls_section();
    }

    private function section_advanced_features() {
        $this->start_controls_section( 'section_advanced', [
            'label' => esc_html__( 'Advanced Features', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        // Bidirectional.
        $this->add_control( 'bidirectional', [
            'label'       => esc_html__( 'Bidirectional Relationship', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::SWITCHER,
            'description' => esc_html__( 'Also show posts where the related post references this post via the same or different field.', 'acf-rel-widget' ),
        ] );

        $this->add_control( 'bi_field_name', [
            'label'     => esc_html__( 'Reverse Field Name', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'condition' => [ 'bidirectional' => 'yes' ],
        ] );

        // AJAX Pagination.
        $this->add_control( 'enable_ajax_pagination', [
            'label'       => esc_html__( 'AJAX Load More', 'acf-rel-widget' ),
            'type'        => \Elementor\Controls_Manager::SWITCHER,
            'description' => esc_html__( 'Append more items on button click without page reload.', 'acf-rel-widget' ),
        ] );

        $this->add_control( 'load_more_text', [
            'label'     => esc_html__( 'Button Text', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'default'   => esc_html__( 'Load More', 'acf-rel-widget' ),
            'condition' => [ 'enable_ajax_pagination' => 'yes' ],
        ] );

        $this->end_controls_section();
    }

    private function section_style_card() {
        $this->start_controls_section( 'section_style_card', [
            'label' => esc_html__( 'Card Style', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        // --- Background Normal / Hover tabs ---
        $this->start_controls_tabs( 'card_bg_tabs' );

        $this->start_controls_tab( 'card_bg_normal', [ 'label' => esc_html__( 'Normal', 'acf-rel-widget' ) ] );

        $this->add_group_control( \Elementor\Group_Control_Background::get_type(), [
            'name'     => 'card_background',
            'label'    => esc_html__( 'Background', 'acf-rel-widget' ),
            'types'    => [ 'classic', 'gradient' ],
            'selector' => '{{WRAPPER}} .acf-rel-widget__card',
        ] );

        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'card_box_shadow',
            'selector' => '{{WRAPPER}} .acf-rel-widget__card',
        ] );

        $this->end_controls_tab();

        $this->start_controls_tab( 'card_bg_hover', [ 'label' => esc_html__( 'Hover', 'acf-rel-widget' ) ] );

        $this->add_group_control( \Elementor\Group_Control_Background::get_type(), [
            'name'     => 'card_background_hover',
            'label'    => esc_html__( 'Background', 'acf-rel-widget' ),
            'types'    => [ 'classic', 'gradient' ],
            'selector' => '{{WRAPPER}} .acf-rel-widget__card:hover',
        ] );

        $this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), [
            'name'     => 'card_box_shadow_hover',
            'selector' => '{{WRAPPER}} .acf-rel-widget__card:hover',
        ] );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // --- Border Radius ---
        $this->add_control( 'card_border_radius', [
            'label'      => esc_html__( 'Border Radius', 'acf-rel-widget' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'separator'  => 'before',
            'selectors'  => [
                '{{WRAPPER}} .acf-rel-widget__card'      => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
                '{{WRAPPER}} .acf-rel-widget__card-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        // --- Padding applied to card-body (not card itself) so image isn't affected ---
        $this->add_responsive_control( 'card_padding', [
            'label'      => esc_html__( 'Content Padding', 'acf-rel-widget' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [ '{{WRAPPER}} .acf-rel-widget__card-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
        ] );

        // --- Text Alignment ---
        $this->add_responsive_control( 'card_text_align', [
            'label'     => esc_html__( 'Text Alignment', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [ 'title' => esc_html__( 'Left', 'acf-rel-widget' ),   'icon' => 'eicon-text-align-left' ],
                'center' => [ 'title' => esc_html__( 'Center', 'acf-rel-widget' ), 'icon' => 'eicon-text-align-center' ],
                'right'  => [ 'title' => esc_html__( 'Right', 'acf-rel-widget' ),  'icon' => 'eicon-text-align-right' ],
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-body' => 'text-align: {{VALUE}};' ],
        ] );

        // --- Empty / Fallback message style ---
        $this->add_control( 'empty_msg_heading', [
            'label'     => esc_html__( 'Fallback Message Style', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'empty_msg_typography',
            'selector' => '{{WRAPPER}} .acf-rel-widget__empty-message',
        ] );

        $this->add_control( 'empty_msg_color', [
            'label'     => esc_html__( 'Color', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'global'    => [ 'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_TEXT ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__empty-message' => 'color: {{VALUE}};' ],
        ] );

        $this->add_control( 'empty_msg_align', [
            'label'     => esc_html__( 'Alignment', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [ 'title' => 'Left',   'icon' => 'eicon-text-align-left' ],
                'center' => [ 'title' => 'Center', 'icon' => 'eicon-text-align-center' ],
                'right'  => [ 'title' => 'Right',  'icon' => 'eicon-text-align-right' ],
            ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget--empty' => 'text-align: {{VALUE}};' ],
        ] );

        $this->end_controls_section();
    }

    private function section_style_typography() {
        $this->start_controls_section( 'section_style_typography', [
            'label' => esc_html__( 'Typography', 'acf-rel-widget' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        // --- Title ---
        $this->add_control( 'typo_title_heading', [
            'label' => esc_html__( 'Title', 'acf-rel-widget' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
        ] );

        $this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [
            'name'     => 'title_typography',
            'global'   => [ 'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Typography::TYPOGRAPHY_PRIMARY ],
            'selector' => '{{WRAPPER}} .acf-rel-widget__card-title',
        ] );

        $this->start_controls_tabs( 'title_color_tabs' );

        $this->start_controls_tab( 'title_color_normal', [ 'label' => esc_html__( 'Normal', 'acf-rel-widget' ) ] );
        $this->add_control( 'title_color', [
            'label'     => esc_html__( 'Color', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'global'    => [ 'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card-title' => 'color: {{VALUE}};' ],
        ] );
        $this->end_controls_tab();

        $this->start_controls_tab( 'title_color_hover', [ 'label' => esc_html__( 'Hover', 'acf-rel-widget' ) ] );
        $this->add_control( 'title_color_hover', [
            'label'     => esc_html__( 'Color', 'acf-rel-widget' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'global'    => [ 'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_ACCENT ],
            'selectors' => [ '{{WRAPPER}} .acf-rel-widget__card:hover .acf-rel-widget__card-title' => 'color: {{VALUE}};' ],
        ] );
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    // -------------------------------------------------------------------------
    // Render
    // -------------------------------------------------------------------------

    protected function render() {
        $settings = $this->get_settings_for_display();

        $field_name = sanitize_key( $settings['field_name'] ?? '' );

        if ( empty( $field_name ) ) {
            if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
                echo '<p style="padding:1em;background:#fff3cd;border-left:4px solid #f0ad4e;font-family:sans-serif;">'
                    . esc_html__( 'ACF Relationship Widget: please select an ACF Relationship field in Data Source.', 'acf-rel-widget' )
                    . '</p>';
            }
            return;
        }

        // Resolve current post ID — use queried object as fallback for editor/preview.
        $post_id = (int) get_the_ID();
        if ( ! $post_id ) {
            $post_id = (int) get_queried_object_id();
        }

        // Build date query.
        $date_query = array();
        $query_date = $settings['query_date'] ?? 'all';
        if ( $query_date !== 'all' ) {
            if ( $query_date === 'custom' ) {
                $date_query = array(
                    'after'     => sanitize_text_field( $settings['query_date_after'] ?? '' ),
                    'before'    => sanitize_text_field( $settings['query_date_before'] ?? '' ),
                    'inclusive' => true,
                );
            } else {
                $periods = array( 'today' => 'day', 'week' => 'week', 'month' => 'month', 'year' => 'year' );
                $date_query = array( 'column' => 'post_date', $periods[ $query_date ] => true );
            }
        }

        // Build taxonomy filter.
        $tax_query = array();
        if ( ! empty( $settings['tax_filter_taxonomy'] ) && ! empty( $settings['tax_filter_terms'] ) ) {
            $tax_query = array( array(
                'taxonomy' => sanitize_key( $settings['tax_filter_taxonomy'] ),
                'field'    => 'slug',
                'terms'    => array_map( 'sanitize_key', explode( ',', $settings['tax_filter_terms'] ) ),
                'operator' => $settings['tax_filter_operator'] ?? 'IN',
            ) );
        }

        // Include / Exclude IDs — support both resolved (from autocomplete) and raw.
        $include_ids = array();
        $exclude_ids = array();
        if ( ( $settings['query_include_exclude'] ?? 'include' ) === 'include' ) {
            $resolved = $settings['query_include_resolved'] ?? '';
            $raw      = $resolved ?: ( $settings['query_include_ids'] ?? '' );
            if ( ! empty( $raw ) ) {
                $include_ids = self::resolve_post_ids( $raw );
            }
        } else {
            $resolved = $settings['query_exclude_resolved'] ?? '';
            $raw      = $resolved ?: ( $settings['query_exclude_ids'] ?? '' );
            if ( ! empty( $raw ) ) {
                $exclude_ids = self::resolve_post_ids( $raw );
            }
        }

        // Responsive limit: use the value for current device.
        $limit = (int) ( $settings['limit'] ?? 6 );

        $query_args = array(
            'post_id'        => $post_id,
            'field_name'     => $field_name,
            'post_type'      => sanitize_key( $settings['query_post_type'] ?? 'any' ),
            'bidirectional'  => ( $settings['bidirectional'] ?? '' ) === 'yes',
            'bi_field_name'  => sanitize_key( $settings['bi_field_name'] ?? '' ),
            'orderby'        => $settings['orderby'] ?? 'post__in',
            'order'          => $settings['order'] ?? 'DESC',
            'limit'          => $limit,
            'offset'         => 0,
            'ignore_sticky'  => ( $settings['ignore_sticky'] ?? 'yes' ) === 'yes',
            'tax_query'      => $tax_query,
            'date_query'     => $date_query,
            'include_ids'    => $include_ids,
            'exclude_ids'    => $exclude_ids,
            'query_id'       => sanitize_key( $settings['query_id'] ?? '' ),
            'masonry'        => ( $settings['masonry'] ?? '' ) === 'yes',
        );

        $result = Query_Builder::get_related( $query_args );

        // Pass widget ID for AJAX context.
        $settings['_widget_id'] = $this->get_id();

        Template_Loader::render( $settings, $result['posts'], $result['total'], $query_args );
    }

    /**
     * Resolve a comma-separated string of post titles or IDs to an array of IDs.
     */
    private static function resolve_post_ids( $raw ) {
        $ids    = array();
        $parts  = array_filter( array_map( 'trim', explode( ',', $raw ) ) );

        foreach ( $parts as $part ) {
            if ( is_numeric( $part ) ) {
                $ids[] = (int) $part;
            } else {
                // Try to find post by title.
                $post = get_page_by_title( $part, OBJECT, 'any' );
                if ( $post ) {
                    $ids[] = (int) $post->ID;
                }
            }
        }

        return array_filter( $ids );
    }
}
