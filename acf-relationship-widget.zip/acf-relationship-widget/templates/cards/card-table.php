<?php
/**
 * Card template: Table row
 * Override: your-theme/acf-rel-widget/card-table.php
 */
defined( 'ABSPATH' ) || exit;

$post_id     = $post->ID;
$title       = get_the_title( $post );
$permalink   = get_permalink( $post );
$link_target = esc_attr( $settings['link_target'] ?? '_self' );
?>
<tr class="acf-rel-widget__row" data-post-id="<?php echo esc_attr( $post_id ); ?>">
    <td class="acf-rel-widget__col acf-rel-widget__col--image">
        <?php if ( ( $settings['show_image'] ?? 'yes' ) === 'yes' && has_post_thumbnail( $post_id ) ) : ?>
            <a href="<?php echo esc_url( $permalink ); ?>" target="<?php echo $link_target; ?>" style="text-decoration:none;">
                <?php echo get_the_post_thumbnail( $post_id, array( 60, 60 ), array(
                    'class' => 'acf-rel-widget__card-image',
                    'alt'   => esc_attr( $title ),
                ) ); ?>
            </a>
        <?php endif; ?>
    </td>
    <td class="acf-rel-widget__col acf-rel-widget__col--title">
        <a href="<?php echo esc_url( $permalink ); ?>" target="<?php echo $link_target; ?>" style="text-decoration:none;color:inherit;">
            <?php echo esc_html( $title ); ?>
        </a>
    </td>
    <td class="acf-rel-widget__col acf-rel-widget__col--meta">
        <?php if ( ( $settings['show_excerpt'] ?? '' ) === 'yes' ) : ?>
            <span class="acf-rel-widget__card-excerpt">
                <?php echo wp_trim_words( get_the_excerpt( $post ), (int) ( $settings['excerpt_length'] ?? 20 ) ); ?>
            </span>
        <?php endif; ?>
    </td>
</tr>
