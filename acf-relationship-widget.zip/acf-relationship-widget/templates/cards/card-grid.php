<?php
/**
 * Card template: Grid
 * Override: your-theme/acf-rel-widget/card-grid.php
 */
defined( 'ABSPATH' ) || exit;

$post_id     = $post->ID;
$title       = get_the_title( $post );
$permalink   = get_permalink( $post );
$link_target = esc_attr( $settings['link_target'] ?? '_self' );
$title_tag   = in_array( $settings['title_tag'] ?? 'h3', array( 'h2', 'h3', 'h4', 'h5', 'p' ), true )
    ? $settings['title_tag'] : 'h3';

// Image display settings.
$img_position   = esc_attr( $settings['image_position'] ?? 'center center' );
$img_size_disp  = esc_attr( $settings['image_size_display'] ?? 'cover' );
?>
<div class="acf-rel-widget__item acf-rel-widget__item--grid">
    <article class="acf-rel-widget__card" data-post-id="<?php echo esc_attr( $post_id ); ?>">
        <a class="acf-rel-widget__card-link" href="<?php echo esc_url( $permalink ); ?>" target="<?php echo $link_target; ?>" aria-label="<?php echo esc_attr( $title ); ?>">

            <?php if ( ( $settings['show_image'] ?? 'yes' ) === 'yes' && has_post_thumbnail( $post_id ) ) : ?>
                <div class="acf-rel-widget__card-image-wrap">
                    <?php
                    $size = $settings['thumbnail_size'] ?? 'medium';
                    echo get_the_post_thumbnail( $post_id, $size, array(
                        'class' => 'acf-rel-widget__card-image',
                        'alt'   => esc_attr( $title ),
                        'style' => 'object-position:' . $img_position . ';object-fit:' . $img_size_disp . ';',
                    ) );
                    ?>
                </div>
            <?php endif; ?>

            <div class="acf-rel-widget__card-body">
                <?php if ( ( $settings['show_title'] ?? 'yes' ) === 'yes' ) : ?>
                    <<?php echo esc_html( $title_tag ); ?> class="acf-rel-widget__card-title">
                        <?php echo esc_html( $title ); ?>
                    </<?php echo esc_html( $title_tag ); ?>>
                <?php endif; ?>
            </div>

        </a>
    </article>
</div>
