<?php
/**
 * Card template: List
 * Override: your-theme/acf-rel-widget/card-list.php
 */
defined( 'ABSPATH' ) || exit;

$post_id        = $post->ID;
$title          = get_the_title( $post );
$permalink      = get_permalink( $post );
$link_target    = esc_attr( $settings['link_target'] ?? '_self' );
$img_position   = esc_attr( $settings['image_position'] ?? 'center center' );
$img_size_disp  = esc_attr( $settings['image_size_display'] ?? 'cover' );
?>
<div class="acf-rel-widget__item acf-rel-widget__item--list">
    <article class="acf-rel-widget__card acf-rel-widget__card--list" data-post-id="<?php echo esc_attr( $post_id ); ?>">
        <a class="acf-rel-widget__card-link" href="<?php echo esc_url( $permalink ); ?>" target="<?php echo $link_target; ?>" aria-label="<?php echo esc_attr( $title ); ?>">

            <?php if ( ( $settings['show_image'] ?? 'yes' ) === 'yes' && has_post_thumbnail( $post_id ) ) : ?>
                <div class="acf-rel-widget__card-image-wrap">
                    <?php echo get_the_post_thumbnail( $post_id, 'thumbnail', array(
                        'class' => 'acf-rel-widget__card-image',
                        'alt'   => esc_attr( $title ),
                        'style' => 'object-position:' . $img_position . ';object-fit:' . $img_size_disp . ';',
                    ) ); ?>
                </div>
            <?php endif; ?>

            <div class="acf-rel-widget__card-body">
                <?php if ( ( $settings['show_title'] ?? 'yes' ) === 'yes' ) : ?>
                    <p class="acf-rel-widget__card-title"><?php echo esc_html( $title ); ?></p>
                <?php endif; ?>
            </div>

        </a>
    </article>
</div>
