<?php
/**
 * Plugin Name:       ACF Relationship Dynamic Widget
 * Plugin URI:        https://github.com/mikhaelamarticioncreodigitals-glitch/acf-relationship-widget
 * Description:       Elementor widget that dynamically displays related posts via ACF Relationship fields, with grid/carousel/list/table layouts, taxonomy filtering, AJAX pagination, and bidirectional relationship support.
 * Version:           1.0.0
 * Author:            Nyx
 * License:           GPL-2.0-or-later
 * Text Domain:       acf-rel-widget
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

defined( 'ABSPATH' ) || exit;

define( 'ACF_REL_WIDGET_VERSION', '1.0.0' );
define( 'ACF_REL_WIDGET_PATH',    plugin_dir_path( __FILE__ ) );
define( 'ACF_REL_WIDGET_URL',     plugin_dir_url( __FILE__ ) );

/**
 * Show admin notice if a dependency is missing.
 */
function acf_rel_widget_missing_dep_notice( $plugin_name ) {
    add_action( 'admin_notices', function() use ( $plugin_name ) {
        echo '<div class="notice notice-error"><p><strong>ACF Relationship Widget</strong> requires <strong>'
            . esc_html( $plugin_name )
            . '</strong> to be installed and active.</p></div>';
    } );
}

/**
 * Load non-Elementor classes and enqueue hooks.
 * Called once we know ACF is available.
 */
function acf_rel_widget_boot() {
    require_once ACF_REL_WIDGET_PATH . 'includes/class-query-builder.php';
    require_once ACF_REL_WIDGET_PATH . 'includes/class-template-loader.php';
    require_once ACF_REL_WIDGET_PATH . 'includes/class-ajax-handler.php';

    add_action( 'wp_enqueue_scripts', 'acf_rel_widget_enqueue_assets' );
    new \ACFRelWidget\Ajax_Handler();
}

/**
 * Register the Elementor widget.
 * Only called from elementor/widgets/register — by which point
 * Elementor\Widget_Base is guaranteed to be available.
 */
function acf_rel_widget_register_widget( $manager ) {
    static $done = false;
    if ( $done ) return;
    $done = true;

    require_once ACF_REL_WIDGET_PATH . 'widgets/class-elementor-widget.php';
    $manager->register( new \ACFRelWidget\Elementor_Widget() );
}

/**
 * Main init — hooked to elementor/init so we run AFTER Elementor is fully
 * bootstrapped. This is more reliable than plugins_loaded for Elementor 4.x.
 */
add_action( 'elementor/init', function() {

    // ACF check — get_field() must exist.
    if ( ! function_exists( 'get_field' ) ) {
        acf_rel_widget_missing_dep_notice( 'Advanced Custom Fields (ACF)' );
        return;
    }

    acf_rel_widget_boot();

    add_action( 'elementor/widgets/register', 'acf_rel_widget_register_widget' );
} );

/**
 * Fallback: if Elementor is NOT active at all, show a notice.
 */
add_action( 'admin_notices', function() {
    if ( ! did_action( 'elementor/init' ) ) {
        // Only show notice on plugins page to avoid noise everywhere.
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && $screen->id === 'plugins' ) {
            echo '<div class="notice notice-warning is-dismissible"><p><strong>ACF Relationship Widget</strong> requires Elementor to be active.</p></div>';
        }
    }
} );

/**
 * AJAX: search posts by title for the Include/Exclude autocomplete.
 */
add_action( 'wp_ajax_acf_rel_search_posts', function() {
    check_ajax_referer( 'acf_rel_widget_nonce', 'nonce' );

    $term      = sanitize_text_field( wp_unslash( $_GET['term'] ?? '' ) );
    $post_type = sanitize_key( $_GET['post_type'] ?? 'any' );

    if ( strlen( $term ) < 2 ) {
        wp_send_json_success( array() );
    }

    $pt = ( empty( $post_type ) || $post_type === 'any' )
        ? array_values( get_post_types( array( 'public' => true ) ) )
        : array( $post_type );

    $query = new WP_Query( array(
        'post_type'      => $pt,
        'post_status'    => 'publish',
        'posts_per_page' => 10,
        's'              => $term,
        'no_found_rows'  => true,
        'fields'         => 'ids',
    ) );

    $results = array();
    foreach ( $query->posts as $id ) {
        $results[] = array(
            'id'    => $id,
            'label' => get_the_title( $id ) . ' (#' . $id . ')',
            'value' => $id,
        );
    }

    wp_send_json_success( $results );
} );

function acf_rel_widget_enqueue_assets() {
    wp_register_style(
        'acf-rel-widget',
        ACF_REL_WIDGET_URL . 'assets/css/widget.css',
        array(),
        ACF_REL_WIDGET_VERSION
    );

    wp_register_script(
        'acf-rel-widget',
        ACF_REL_WIDGET_URL . 'assets/js/widget.js',
        array( 'jquery' ),
        ACF_REL_WIDGET_VERSION,
        true
    );

    wp_localize_script( 'acf-rel-widget', 'acfRelWidget', array(
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'acf_rel_widget_nonce' ),
        'i18n'    => array(
            'loading'  => __( 'Loading...', 'acf-rel-widget' ),
            'noMore'   => __( 'No more items.', 'acf-rel-widget' ),
            'error'    => __( 'Failed to load items.', 'acf-rel-widget' ),
        ),
    ) );
}
