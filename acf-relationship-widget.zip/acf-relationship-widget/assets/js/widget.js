/* global acfRelWidget, Swiper */
(function ($) {
    'use strict';

    // -------------------------------------------------------------------------
    // Carousel init (Swiper)
    // -------------------------------------------------------------------------
    function initCarousels() {
        document.querySelectorAll('.acf-rel-widget--carousel .acf-rel-widget__swiper').forEach(function (el) {
            var widget  = el.closest('.acf-rel-widget');
            var cols    = parseInt(widget.dataset.columns, 10) || 3;
            var autoplayEnabled = widget.dataset.autoplay === 'yes';
            var autoplayDelay   = parseInt(widget.dataset.autoplayDelay, 10) || 3000;

            // Guard: Swiper may not be loaded on non-carousel pages.
            if (typeof Swiper === 'undefined') return;

            new Swiper(el, {
                slidesPerView: 1,
                spaceBetween: 20,
                loop: false,
                pagination: {
                    el: el.querySelector('.swiper-pagination'),
                    clickable: true,
                },
                navigation: {
                    nextEl: el.querySelector('.swiper-button-next'),
                    prevEl: el.querySelector('.swiper-button-prev'),
                },
                autoplay: autoplayEnabled ? { delay: autoplayDelay, disableOnInteraction: false } : false,
                breakpoints: {
                    480: { slidesPerView: Math.min(2, cols) },
                    768: { slidesPerView: Math.min(3, cols) },
                    1024: { slidesPerView: cols },
                },
            });
        });
    }

    // -------------------------------------------------------------------------
    // AJAX Load More
    // -------------------------------------------------------------------------
    function initLoadMore() {
        $(document).on('click', '.acf-rel-widget__load-more', function () {
            var $btn    = $(this);
            var $widget = $btn.closest('.acf-rel-widget');
            var offset  = parseInt($btn.data('offset'), 10) || 0;

            var rawQuery = $widget.data('query');
            var query    = (typeof rawQuery === 'object') ? rawQuery : {};

            var settings = $widget.data('settings') || {};

            $btn.prop('disabled', true).addClass('acf-rel-widget__load-more--loading');
            $btn.text(acfRelWidget.i18n.loading);

            $.post(acfRelWidget.ajaxUrl, {
                action:   'acf_rel_widget_load_more',
                nonce:    acfRelWidget.nonce,
                query:    JSON.stringify(query),
                offset:   offset,
                settings: JSON.stringify(settings),
            })
            .done(function (response) {
                if (!response.success) {
                    $btn.text(acfRelWidget.i18n.error).prop('disabled', false).removeClass('acf-rel-widget__load-more--loading');
                    return;
                }

                var data    = response.data;
                var layout  = $widget.data('layout');

                // Append new cards to the right container.
                if (layout === 'carousel') {
                    var swiper = $widget.find('.swiper')[0] ? $widget.find('.swiper')[0].swiper : null;
                    if (swiper) {
                        $(data.html).each(function () {
                            swiper.appendSlide(this.outerHTML);
                        });
                        swiper.update();
                    } else {
                        $widget.find('.swiper-wrapper').append(data.html);
                    }
                } else if (layout === 'table') {
                    $widget.find('tbody').append(data.html);
                } else {
                    $widget.find('.acf-rel-widget__items').append(data.html);
                }

                // Update offset for next click.
                $btn.data('offset', data.offset);

                if (data.has_more) {
                    $btn
                        .prop('disabled', false)
                        .removeClass('acf-rel-widget__load-more--loading')
                        .text($widget.data('loadMoreText') || 'Load More');
                } else {
                    $btn.closest('.acf-rel-widget__load-more-wrap').html(
                        '<p class="acf-rel-widget__no-more">' + acfRelWidget.i18n.noMore + '</p>'
                    );
                }
            })
            .fail(function () {
                $btn.text(acfRelWidget.i18n.error).prop('disabled', false).removeClass('acf-rel-widget__load-more--loading');
            });
        });
    }

    // -------------------------------------------------------------------------
    // Boot
    // -------------------------------------------------------------------------
    $(function () {
        initCarousels();
        initLoadMore();
    });

    // Re-init after Elementor frontend renders (editor live preview).
    $(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/acf_relationship_widget.default', function () {
                initCarousels();
            });
        }
    });

}(jQuery));

/* ==========================================================================
   Elementor Editor: Post Search Autocomplete for Include/Exclude fields
   ========================================================================== */
(function ($) {
    'use strict';

    function initPostSearch() {
        // Only run inside Elementor editor.
        if ( typeof elementor === 'undefined' ) return;

        elementor.hooks.addAction( 'panel/open_editor/widget/acf_relationship_widget', function ( panel ) {
            setTimeout( function () {
                attachAutocomplete( panel.$el );
            }, 300 );
        } );
    }

    function attachAutocomplete( $panel ) {
        $panel.find( '.elementor-control-query_include_ids input, .elementor-control-query_exclude_ids input' ).each( function () {
            var $input = $( this );
            if ( $input.data( 'acr-search' ) ) return; // already attached
            $input.data( 'acr-search', true );

            var $suggestions = $( '<ul class="acr-suggestions"></ul>' ).insertAfter( $input );
            var timeout;

            $input.on( 'input', function () {
                clearTimeout( timeout );
                var term = $input.val().split( ',' ).pop().trim();
                if ( term.length < 2 ) { $suggestions.empty().hide(); return; }

                timeout = setTimeout( function () {
                    var postType = $panel.find( '.elementor-control-query_post_type select' ).val() || 'any';

                    $.get( acfRelWidget.ajaxUrl, {
                        action:    'acf_rel_search_posts',
                        nonce:     acfRelWidget.nonce,
                        term:      term,
                        post_type: postType,
                    }, function ( res ) {
                        $suggestions.empty();
                        if ( ! res.success || ! res.data.length ) { $suggestions.hide(); return; }

                        res.data.forEach( function ( item ) {
                            $( '<li>' ).text( item.label ).on( 'click', function () {
                                var parts  = $input.val().split( ',' );
                                parts.pop();
                                parts.push( item.id );
                                $input.val( parts.join( ', ' ) + ', ' ).trigger( 'input' ).trigger( 'change' );
                                $suggestions.empty().hide();
                            } ).appendTo( $suggestions );
                        } );

                        $suggestions.show();
                    } );
                }, 300 );
            } );

            $( document ).on( 'click', function ( e ) {
                if ( ! $( e.target ).closest( $suggestions ).length ) {
                    $suggestions.empty().hide();
                }
            } );
        } );
    }

    $( window ).on( 'elementor/frontend/init', initPostSearch );

}(jQuery));
