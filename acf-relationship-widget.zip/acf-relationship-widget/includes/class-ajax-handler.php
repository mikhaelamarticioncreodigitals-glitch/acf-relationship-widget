<?php
namespace ACFRelWidget;

defined( 'ABSPATH' ) || exit;

/**
 * Handles AJAX "Load More" requests for the widget.
 */
class Ajax_Handler {

    public function __construct() {
        add_action( 'wp_ajax_acf_rel_widget_load_more',        [ $this, 'handle' ] );
        add_action( 'wp_ajax_nopriv_acf_rel_widget_load_more', [ $this, 'handle' ] );
    }

    public function handle() {
        check_ajax_referer( 'acf_rel_widget_nonce', 'nonce' );

        $raw_query = isset( $_POST['query'] ) ? wp_unslash( $_POST['query'] ) : '{}';
        $query_args = json_decode( $raw_query, true );

        if ( ! is_array( $query_args ) ) {
            wp_send_json_error( [ 'message' => 'Invalid query args.' ], 400 );
        }

        $offset = max( 0, (int) ( $_POST['offset'] ?? 0 ) );
        $query_args['offset'] = $offset;

        // Sanitize critical args to prevent abuse.
        $query_args['post_id']       = (int) ( $query_args['post_id'] ?? 0 );
        $query_args['field_name']    = sanitize_key( $query_args['field_name'] ?? '' );
        $query_args['limit']         = min( 100, max( 1, (int) ( $query_args['limit'] ?? 6 ) ) );
        $query_args['bidirectional'] = (bool) ( $query_args['bidirectional'] ?? false );
        $query_args['bi_field_name'] = sanitize_key( $query_args['bi_field_name'] ?? '' );
        $query_args['orderby']       = sanitize_key( $query_args['orderby'] ?? 'post__in' );

        $result = Query_Builder::get_related( $query_args );

        if ( empty( $result['posts'] ) ) {
            wp_send_json_success( [ 'html' => '', 'total' => 0, 'has_more' => false ] );
        }

        $settings = isset( $_POST['settings'] )
            ? json_decode( wp_unslash( $_POST['settings'] ), true )
            : [];

        if ( ! is_array( $settings ) ) {
            $settings = [];
        }

        // Capture rendered HTML.
        ob_start();
        foreach ( $result['posts'] as $post ) {
            Template_Loader::render_php_card( $post, $settings, $settings['layout'] ?? 'grid' );
        }
        $html = ob_get_clean();

        $loaded_so_far = $offset + count( $result['posts'] );
        $has_more      = $loaded_so_far < $result['total'];

        wp_send_json_success( [
            'html'     => $html,
            'total'    => $result['total'],
            'has_more' => $has_more,
            'offset'   => $loaded_so_far,
        ] );
    }
}
