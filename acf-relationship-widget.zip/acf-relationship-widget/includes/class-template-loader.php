<?php
namespace ACFRelWidget;

defined( 'ABSPATH' ) || exit;

/**
 * Resolves and renders card templates.
 *
 * Priority order:
 *   1. Child theme:  {theme}/acf-rel-widget/card-{layout}.php
 *   2. Parent theme: {theme}/acf-rel-widget/card-{layout}.php
 *   3. Plugin:       templates/cards/card-{layout}.php
 *
 * If an Elementor Loop Template ID is supplied and Elementor Pro is active,
 * that template is rendered instead (wrapping each post in the loop context).
 */
class Template_Loader {

    /**
     * Render the full widget output.
     *
     * @param array     $settings   Widget settings from Elementor.
     * @param \WP_Post[] $posts     Related posts.
     * @param int        $total     Total found posts (for pagination).
     * @param array      $query_args Original query args for AJAX re-use.
     */
    public static function render( array $settings, array $posts, int $total, array $query_args) {
        if ( empty( $posts ) ) {
            self::render_empty_state( $settings );
            return;
        }

        $layout          = $settings['layout'] ?? 'grid';
        $columns         = max( 1, min( 6, (int) ( $settings['columns'] ?? 3 ) ) );
        $loop_template   = (int) ( $settings['elementor_loop_template'] ?? 0 );
        $limit           = (int) ( $settings['limit'] ?? 6 );
        $enable_ajax     = ! empty( $settings['enable_ajax_pagination'] ) && $settings['enable_ajax_pagination'] === 'yes';
        $widget_id       = $settings['_widget_id'] ?? uniqid( 'acrw-' );

        $data_attrs = sprintf(
            'data-widget-id="%s" data-layout="%s" data-columns="%d" data-limit="%d" data-total="%d" data-query="%s"',
            esc_attr( $widget_id ),
            esc_attr( $layout ),
            $columns,
            $limit,
            $total,
            esc_attr( wp_json_encode( $query_args ) )
        );

        wp_enqueue_style( 'acf-rel-widget' );
        wp_enqueue_script( 'acf-rel-widget' );

        // Carousel needs Swiper.
        if ( $layout === 'carousel' ) {
            self::enqueue_swiper();
        }

        $is_masonry    = ! empty( $settings['masonry'] ) && $settings['masonry'] === 'yes' && $layout === 'grid';

        $wrapper_class = implode( ' ', array_filter( [
            'acf-rel-widget',
            'acf-rel-widget--' . sanitize_html_class( $layout ),
            'acf-rel-widget--cols-' . $columns,
            $is_masonry ? 'acf-rel-widget--masonry' : '',
        ] ) );

        echo '<div class="' . esc_attr( $wrapper_class ) . '" ' . $data_attrs . '>';

        if ( $layout === 'carousel' ) {
            echo '<div class="swiper acf-rel-widget__swiper"><div class="swiper-wrapper">';
        } elseif ( $layout === 'table' ) {
            echo '<table class="acf-rel-widget__table"><thead>';
            echo '<tr><th>' . esc_html__( 'Image', 'acf-rel-widget' ) . '</th><th>' . esc_html__( 'Title', 'acf-rel-widget' ) . '</th><th>' . esc_html__( 'Details', 'acf-rel-widget' ) . '</th></tr>';
            echo '</thead><tbody>';
        } else {
            echo '<div class="acf-rel-widget__items">';
        }

        foreach ( $posts as $post ) {
            if ( $loop_template && self::is_elementor_pro_active() ) {
                self::render_elementor_loop_template( $post, $loop_template, $layout );
            } else {
                self::render_php_card( $post, $settings, $layout );
            }
        }

        if ( $layout === 'carousel' ) {
            echo '</div>'; // .swiper-wrapper
            echo '<div class="swiper-pagination"></div>';
            echo '<div class="swiper-button-prev"></div><div class="swiper-button-next"></div>';
            echo '</div>'; // .swiper
        } elseif ( $layout === 'table' ) {
            echo '</tbody></table>';
        } else {
            echo '</div>'; // .acf-rel-widget__items
        }

        // AJAX "Load More" button.
        if ( $enable_ajax && $total > $limit ) {
            echo '<div class="acf-rel-widget__load-more-wrap">';
            echo '<button class="acf-rel-widget__load-more" data-offset="' . esc_attr( $limit ) . '">';
            echo esc_html__( 'Load More', 'acf-rel-widget' );
            echo '</button>';
            echo '</div>';
        }

        echo '</div>'; // .acf-rel-widget
    }

    /**
     * Render a single card using the PHP partial system.
     */
    public static function render_php_card( \WP_Post $post, array $settings, string $layout) {
        $template = self::locate_template( $layout );
        include $template; // phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable
    }

    /**
     * Render a post using an Elementor Loop Template.
     */
    private static function render_elementor_loop_template( \WP_Post $post, int $template_id, string $layout) {
        global $wp_query;

        $wrapper = $layout === 'carousel' ? 'swiper-slide' : 'acf-rel-widget__item';
        echo '<div class="' . esc_attr( $wrapper ) . '">';

        // Temporarily override the global post.
        $original = $wp_query->post;
        setup_postdata( $post );
        $GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride

        echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $template_id, true );

        $GLOBALS['post'] = $original; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
        wp_reset_postdata();

        echo '</div>';
    }

    /**
     * Render empty state.
     */
    private static function render_empty_state( array $settings) {
        $mode    = $settings['empty_state'] ?? 'hide';
        $message = $settings['empty_message'] ?? __( 'No related items found.', 'acf-rel-widget' );

        if ( $mode === 'hide' ) {
            return;
        }

        echo '<div class="acf-rel-widget acf-rel-widget--empty">';
        echo '<p class="acf-rel-widget__empty-message">' . esc_html( $message ) . '</p>';
        echo '</div>';
    }

    /**
     * Locate card template — theme override → plugin fallback.
     */
    private static function locate_template( string $layout) {
        $filename = 'card-' . sanitize_key( $layout ) . '.php';
        $subdir   = 'acf-rel-widget/';

        $theme_template = locate_template( [ $subdir . $filename ] );

        if ( $theme_template ) {
            return $theme_template;
        }

        $plugin_template = ACF_REL_WIDGET_PATH . 'templates/cards/' . $filename;

        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }

        // Ultimate fallback: grid card.
        return ACF_REL_WIDGET_PATH . 'templates/cards/card-grid.php';
    }

    /**
     * Check if Elementor Pro is active.
     */
    private static function is_elementor_pro_active() {
        return defined( 'ELEMENTOR_PRO_VERSION' );
    }

    /**
     * Enqueue Swiper.js for carousel layout.
     */
    private static function enqueue_swiper() {
        wp_enqueue_style(
            'swiper',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
            [],
            '11'
        );
        wp_enqueue_script(
            'swiper',
            'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
            [],
            '11',
            true
        );
    }
}
