<?php
namespace ACFRelWidget;

defined( 'ABSPATH' ) || exit;

/**
 * Builds and executes WP_Query for ACF Relationship fields.
 */
class Query_Builder {

    public static function get_related( array $args ) {
        $defaults = array(
            'post_id'       => 0,
            'field_name'    => '',
            'post_type'     => 'any',
            'bidirectional' => false,
            'bi_field_name' => '',
            'orderby'       => 'post__in',
            'order'         => 'DESC',
            'limit'         => 6,
            'offset'        => 0,
            'ignore_sticky' => true,
            'tax_query'     => array(),
            'date_query'    => array(),
            'include_ids'   => array(),
            'exclude_ids'   => array(),
            'query_id'      => '',
        );

        $args = wp_parse_args( $args, $defaults );

        if ( empty( $args['field_name'] ) ) {
            return array( 'posts' => array(), 'total' => 0 );
        }

        // Resolve post ID — fall back to queried object for editor context.
        $post_id = (int) $args['post_id'];
        if ( ! $post_id ) {
            $post_id = (int) get_queried_object_id();
        }
        if ( ! $post_id ) {
            return array( 'posts' => array(), 'total' => 0 );
        }

        $ids = self::get_relationship_ids( $post_id, $args['field_name'] );

        // Bidirectional: also find posts that reference current post.
        if ( $args['bidirectional'] && ! empty( $args['bi_field_name'] ) ) {
            $ids = array_unique(
                array_merge( $ids, self::get_reverse_ids( $post_id, $args['bi_field_name'] ) )
            );
        }

        if ( empty( $ids ) ) {
            return array( 'posts' => array(), 'total' => 0 );
        }

        // Apply include filter — intersect with ACF IDs.
        if ( ! empty( $args['include_ids'] ) ) {
            $ids = array_intersect( $ids, $args['include_ids'] );
        }

        // Apply exclude filter.
        if ( ! empty( $args['exclude_ids'] ) ) {
            $ids = array_diff( $ids, $args['exclude_ids'] );
        }

        $ids = array_values( array_filter( $ids ) );

        if ( empty( $ids ) ) {
            return array( 'posts' => array(), 'total' => 0 );
        }

        // When post_type is 'any', we must list all public post types explicitly.
        // WP_Query with post_type='any' + post__in does NOT reliably return all types.
        if ( empty( $args['post_type'] ) || $args['post_type'] === 'any' ) {
            $post_type_value = array_values( get_post_types( array( 'public' => true ) ) );
        } else {
            $post_type_value = sanitize_key( $args['post_type'] );
        }

        $query_args = array(
            'post__in'            => $ids,
            'post_type'           => $post_type_value,
            'post_status'         => 'publish',
            'posts_per_page'      => (int) $args['limit'],
            'offset'              => (int) $args['offset'],
            'no_found_rows'       => false,
            'ignore_sticky_posts' => (bool) $args['ignore_sticky'],
        );

        // Ordering.
        if ( $args['orderby'] === 'post__in' ) {
            $query_args['orderby'] = 'post__in';
        } else {
            $query_args['orderby'] = sanitize_key( $args['orderby'] );
            $query_args['order']   = in_array( strtoupper( $args['order'] ), array( 'ASC', 'DESC' ), true )
                ? strtoupper( $args['order'] ) : 'DESC';
        }

        // Taxonomy filter.
        if ( ! empty( $args['tax_query'] ) ) {
            $query_args['tax_query'] = $args['tax_query']; // phpcs:ignore WordPress.DB.SlowDBQuery
        }

        // Date filter.
        if ( ! empty( $args['date_query'] ) ) {
            $query_args['date_query'] = $args['date_query'];
        }

        $query = new \WP_Query( $query_args );

        // Allow external filtering via query ID (mirrors Elementor Loop Grid behaviour).
        if ( ! empty( $args['query_id'] ) ) {
            do_action( 'elementor/query/' . $args['query_id'], $query, $args );
        }

        return array(
            'posts' => $query->posts,
            'total' => (int) $query->found_posts,
        );
    }

    private static function get_relationship_ids( int $post_id, string $field_name ) {
        $value = get_field( $field_name, $post_id );

        // Try queried object fallback if post_id returned nothing.
        if ( empty( $value ) ) {
            $fallback = (int) get_queried_object_id();
            if ( $fallback && $fallback !== $post_id ) {
                $value = get_field( $field_name, $fallback );
            }
        }

        if ( empty( $value ) ) {
            return array();
        }

        $ids = array();
        foreach ( (array) $value as $item ) {
            if ( is_object( $item ) && isset( $item->ID ) ) {
                $ids[] = (int) $item->ID;
            } elseif ( is_array( $item ) && isset( $item['ID'] ) ) {
                $ids[] = (int) $item['ID'];
            } elseif ( is_numeric( $item ) ) {
                $ids[] = (int) $item;
            }
        }

        return array_filter( $ids );
    }

    private static function get_reverse_ids( int $post_id, string $bi_field_name ) {
        $query = new \WP_Query( array(
            'post_type'      => 'any',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
                'relation' => 'OR',
                array(
                    'key'     => $bi_field_name,
                    'value'   => '"' . $post_id . '"',
                    'compare' => 'LIKE',
                ),
                array(
                    'key'     => $bi_field_name,
                    'value'   => (string) $post_id,
                    'compare' => '=',
                ),
            ),
        ) );

        return array_map( 'intval', $query->posts );
    }
}
